const Database = require('better-sqlite3');
const path = require('path');

const DB_PATH = path.join(__dirname, 'climbing.db');
const db = new Database(DB_PATH);

console.log("Starting DB migration for children table...");
try {
  const schemaRow = db.prepare("SELECT sql FROM sqlite_master WHERE type='table' AND name='children'").get();
  
  if (schemaRow && !schemaRow.sql.includes('UNIQUE(competition_id, access_key)')) {
    console.log("Migrating children table to remove access_key UNIQUE constraint...");
    
    // Disable foreign keys for rotation
    db.pragma('foreign_keys = OFF');
    
    const migrate = db.transaction(() => {
      // 1. Rename old table
      db.exec(`ALTER TABLE children RENAME TO children_old;`);
      
      // 2. Create new table
      db.exec(`
        CREATE TABLE children (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          competition_id INTEGER NOT NULL,
          category_id INTEGER NOT NULL,
          first_name TEXT NOT NULL,
          last_name TEXT NOT NULL,
          gender TEXT NOT NULL CHECK(gender IN ('male', 'female')),
          access_key TEXT NOT NULL,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (competition_id) REFERENCES competitions(id) ON DELETE CASCADE,
          FOREIGN KEY (category_id) REFERENCES comp_categories(id) ON DELETE CASCADE,
          UNIQUE(competition_id, access_key),
          UNIQUE(competition_id, first_name, last_name, gender)
        );
      `);
      
      // 3. Copy data
      db.exec(`INSERT INTO children SELECT * FROM children_old;`);
      
      // 4. Drop old table
      db.exec(`DROP TABLE children_old;`);
    });
    
    migrate();
    db.pragma('foreign_keys = ON');
    
    console.log("Migration successful.");
  } else {
    console.log("Migration already applied or table not found.");
  }
} catch (e) {
  console.error("Migration failed:", e);
}
